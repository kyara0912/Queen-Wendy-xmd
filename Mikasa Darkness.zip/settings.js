require("./lib/module.js")

// ===== !! Setting Bot & Owner !! ===== \\
global.owner = "243988778057"
global.BotName = "Mikasa Darkness" 
global.OwnerName = "Mikasa Mods"
global.packname = "Create By"
global.author = "Mikasa Mods"

// ===== !! Setting Url !! ===== \\
global.thumbUrl = "https://files.catbox.moe/fwo11s.jpg" //buat sendiri di web tu
global.LinkCh = "https://whatsapp.com/channel/0029VamzCT5GzzKRylqvj33l"
global.IDch = "120363334353222571@newsletter"


let file = require.resolve(__filename) 
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.cyan("File Update => "), chalk.cyan.bgBlue.bold(`${__filename}`))
delete require.cache[file]
require(file)
})